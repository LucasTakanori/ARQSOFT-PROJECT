var searchData=
[
  ['save_5fspreadsheet_5fto_5ffile_0',['save_spreadsheet_to_file',['../classusecasesmarker_1_1spreadsheet__controller__for__checker_1_1_i_spreadsheet_controller_for_checker.html#ad9b0f3e1341d09e3a86bd5d80ac37410',1,'usecasesmarker::spreadsheet_controller_for_checker::ISpreadsheetControllerForChecker']]],
  ['set_5fcell_5fcontent_1',['set_cell_content',['../classusecasesmarker_1_1spreadsheet__controller__for__checker_1_1_i_spreadsheet_controller_for_checker.html#a1f1b3d6c171e87cebdb86d85951efecb',1,'usecasesmarker::spreadsheet_controller_for_checker::ISpreadsheetControllerForChecker']]]
];
