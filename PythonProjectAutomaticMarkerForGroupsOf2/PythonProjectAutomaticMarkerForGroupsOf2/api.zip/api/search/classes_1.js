var searchData=
[
  ['readingspreadsheetexception_0',['ReadingSpreadsheetException',['../classusecasesmarker_1_1reading__spreadsheet__exception_1_1_reading_spreadsheet_exception.html',1,'usecasesmarker::reading_spreadsheet_exception']]]
];
