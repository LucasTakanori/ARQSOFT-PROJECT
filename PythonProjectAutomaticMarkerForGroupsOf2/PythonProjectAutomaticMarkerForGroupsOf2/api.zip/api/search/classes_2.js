var searchData=
[
  ['savingspreadsheetexception_0',['SavingSpreadsheetException',['../classusecasesmarker_1_1saving__spreadsheet__exception_1_1_saving_spreadsheet_exception.html',1,'usecasesmarker::saving_spreadsheet_exception']]],
  ['spreadsheetfactoryforchecker_1',['SpreadSheetFactoryForChecker',['../classusecasesmarker_1_1spread__sheet__factory__for__checker_1_1_spread_sheet_factory_for_checker.html',1,'usecasesmarker::spread_sheet_factory_for_checker']]]
];
