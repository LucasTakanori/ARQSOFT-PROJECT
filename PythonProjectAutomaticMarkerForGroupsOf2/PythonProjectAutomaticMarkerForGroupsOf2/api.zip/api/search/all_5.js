var searchData=
[
  ['save_5fspreadsheet_5fto_5ffile_0',['save_spreadsheet_to_file',['../classusecasesmarker_1_1spreadsheet__controller__for__checker_1_1_i_spreadsheet_controller_for_checker.html#ad9b0f3e1341d09e3a86bd5d80ac37410',1,'usecasesmarker::spreadsheet_controller_for_checker::ISpreadsheetControllerForChecker']]],
  ['savingspreadsheetexception_1',['SavingSpreadsheetException',['../classusecasesmarker_1_1saving__spreadsheet__exception_1_1_saving_spreadsheet_exception.html',1,'usecasesmarker::saving_spreadsheet_exception']]],
  ['set_5fcell_5fcontent_2',['set_cell_content',['../classusecasesmarker_1_1spreadsheet__controller__for__checker_1_1_i_spreadsheet_controller_for_checker.html#a1f1b3d6c171e87cebdb86d85951efecb',1,'usecasesmarker::spreadsheet_controller_for_checker::ISpreadsheetControllerForChecker']]],
  ['spreadsheetfactoryforchecker_3',['SpreadSheetFactoryForChecker',['../classusecasesmarker_1_1spread__sheet__factory__for__checker_1_1_spread_sheet_factory_for_checker.html',1,'usecasesmarker::spread_sheet_factory_for_checker']]]
];
