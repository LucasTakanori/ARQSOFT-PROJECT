var searchData=
[
  ['get_5fcell_5fcontent_5fas_5ffloat_0',['get_cell_content_as_float',['../classusecasesmarker_1_1spreadsheet__controller__for__checker_1_1_i_spreadsheet_controller_for_checker.html#aaec4db9800cec9cfbb686ba1e3908a09',1,'usecasesmarker::spreadsheet_controller_for_checker::ISpreadsheetControllerForChecker']]],
  ['get_5fcell_5fcontent_5fas_5fstring_1',['get_cell_content_as_string',['../classusecasesmarker_1_1spreadsheet__controller__for__checker_1_1_i_spreadsheet_controller_for_checker.html#a0633a0f6cb0868202ca1783f28215565',1,'usecasesmarker::spreadsheet_controller_for_checker::ISpreadsheetControllerForChecker']]],
  ['get_5fcell_5fformula_5fexpression_2',['get_cell_formula_expression',['../classusecasesmarker_1_1spreadsheet__controller__for__checker_1_1_i_spreadsheet_controller_for_checker.html#aaa22cf430c70b837cdf49eef51863326',1,'usecasesmarker::spreadsheet_controller_for_checker::ISpreadsheetControllerForChecker']]]
];
